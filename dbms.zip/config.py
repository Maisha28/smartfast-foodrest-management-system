import os

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'smartfast-restaurant-secret-key-2024'
    SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://root:Kaashvi2804@localhost/smartfast_pdf'
    SQLALCHEMY_TRACK_MODIFICATIONS = False