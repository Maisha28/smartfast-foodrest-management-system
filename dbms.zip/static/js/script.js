// Custom JavaScript for your application
document.addEventListener('DOMContentLoaded', function() {
    console.log('SmartFast Restaurant System loaded');
});