from flask import Flask, render_template, request, jsonify, redirect, url_for, flash
from models import db, Customer, Supplier, Staff, Inventory, MenuItem, Order, OrderItem, Feedback, WasteLog, RecipeIngredient, InventoryAudit
from datetime import datetime
from decimal import Decimal, InvalidOperation
import json
from sqlalchemy import text

def create_app():
    app = Flask(__name__)
    app.config.from_object('config.Config')
    db.init_app(app)
    
    return app

app = create_app()

# Helper functions
def safe_decimal(value, default='0.00'):
    """Safely convert to Decimal"""
    if value is None or value == '':
        return Decimal(default)
    try:
        if isinstance(value, Decimal):
            return value
        return Decimal(str(value))
    except (InvalidOperation, ValueError):
        return Decimal(default)

def get_form_value(key, required=False):
    """Safely get form value with validation"""
    value = request.form.get(key)
    if required and (value is None or value.strip() == ''):
        raise ValueError(f"{key.replace('_', ' ').title()} is required")
    return value

@app.route('/')
def index():
    try:
        total_customers = Customer.query.count()
        total_orders = Order.query.count()
        pending_orders = Order.query.filter_by(status='pending').count()
        return render_template('index.html',
                             total_customers=total_customers,
                             total_orders=total_orders,
                             pending_orders=pending_orders)
    except Exception as e:
        flash(f"Error loading dashboard: {str(e)}", "error")
        return render_template('index.html', 
                             total_customers=0, 
                             total_orders=0, 
                             pending_orders=0)

@app.route('/customers')
def customers():
    try:
        customers_list = Customer.query.all()
        return render_template('customers.html', customers=customers_list)
    except Exception as e:
        flash(f"Error loading customers: {str(e)}", "error")
        return render_template('customers.html', customers=[])

@app.route('/customers/add', methods=['POST'])
def add_customer():
    try:
        name = get_form_value('name', required=True)
        email = get_form_value('email')
        phone = get_form_value('phone')
        
        new_customer = Customer(
            name=name.strip(),
            email=email.strip() if email else None,
            phone=phone.strip() if phone else None,
            visit_count=0,
            total_spent=Decimal('0.00'),
            last_visit=None
        )
        
        db.session.add(new_customer)
        db.session.commit()
        flash('Customer added successfully!', 'success')
        
    except ValueError as e:
        db.session.rollback()
        flash(str(e), 'error')
    except Exception as e:
        db.session.rollback()
        flash(f'Error adding customer: {str(e)}', 'error')
    
    return redirect(url_for('customers'))

@app.route('/menu')
def menu():
    try:
        menu_items = MenuItem.query.all()
        return render_template('menu.html', menu_items=menu_items)
    except Exception as e:
        flash(f"Error loading menu: {str(e)}", "error")
        return render_template('menu.html', menu_items=[])

@app.route('/menu/add', methods=['POST'])
def add_menu_item():
    try:
        name = get_form_value('name', required=True)
        cost_price = safe_decimal(request.form.get('cost_price'))
        selling_price = safe_decimal(request.form.get('selling_price'))
        
        # Validate prices
        if cost_price < 0 or selling_price < 0:
            flash('Prices cannot be negative', 'error')
            return redirect(url_for('menu'))
            
        if selling_price < cost_price:
            flash('Selling price should be greater than cost price', 'warning')
        
        new_item = MenuItem(
            name=name.strip(),
            cost_price=cost_price,
            selling_price=selling_price
        )
        
        db.session.add(new_item)
        db.session.commit()
        flash('Menu item added successfully!', 'success')
        
    except ValueError as e:
        db.session.rollback()
        flash(str(e), 'error')
    except Exception as e:
        db.session.rollback()
        flash(f'Error adding menu item: {str(e)}', 'error')
    
    return redirect(url_for('menu'))

@app.route('/orders')
def orders():
    try:
        orders_list = Order.query.all()
        menu_items = MenuItem.query.all()
        customers = Customer.query.all()
        staff_members = Staff.query.all()
        
        safe_orders = []
        for order in orders_list:
            safe_order = {
                'order_id': order.order_id,
                'customer': order.customer,
                'total_amount': float(order.total_amount) if order.total_amount else 0.0,
                'status': order.status,
                'order_date': order.order_date,
                'order_items': order.order_items
            }
            safe_orders.append(safe_order)
        
        return render_template('orders.html', 
                             orders=safe_orders, 
                             menu_items=menu_items, 
                             customers=customers, 
                             staff=staff_members)
    except Exception as e:
        flash(f"Error loading orders: {str(e)}", "error")
        return render_template('orders.html', orders=[], menu_items=[], customers=[], staff=[])

@app.route('/orders/create', methods=['POST'])
def create_order():
    try:
        customer_id = request.form.get('customer_id')
        staff_id = request.form.get('staff_id')
        
        if not customer_id or not staff_id:
            flash('Customer and staff selection are required', 'error')
            return redirect(url_for('orders'))
        
        new_order = Order(
            customer_id=int(customer_id),
            created_by_staff=int(staff_id),
            total_amount=Decimal('0.00')
        )
        
        db.session.add(new_order)
        db.session.commit()
        flash('Order created successfully!', 'success')
        
    except Exception as e:
        db.session.rollback()
        flash(f'Error creating order: {str(e)}', 'error')
    
    return redirect(url_for('orders'))

@app.route('/orders/<int:order_id>/add_item', methods=['POST'])
def add_order_item(order_id):
    try:
        item_id = request.form.get('item_id')
        quantity = request.form.get('quantity')
        
        if not item_id or not quantity:
            flash('Item and quantity are required', 'error')
            return redirect(url_for('orders'))
        
        menu_item = MenuItem.query.get(int(item_id))
        if not menu_item:
            flash('Menu item not found', 'error')
            return redirect(url_for('orders'))
        
        quantity_int = int(quantity)
        if quantity_int <= 0:
            flash('Quantity must be positive', 'error')
            return redirect(url_for('orders'))
        
        unit_price = safe_decimal(menu_item.selling_price)
        
        order_item = OrderItem(
            order_id=order_id,
            item_id=int(item_id),
            quantity=quantity_int,
            unit_price=unit_price
        )
        
        db.session.add(order_item)
        
        # Update order total
        order = Order.query.get(order_id)
        if order:
            total_amount = Decimal('0.00')
            for item in order.order_items:
                item_quantity = safe_decimal(item.quantity)
                item_unit_price = safe_decimal(item.unit_price)
                total_amount += item_quantity * item_unit_price
            
            order.total_amount = total_amount
        
        db.session.commit()
        flash('Item added to order successfully!', 'success')
        
    except Exception as e:
        db.session.rollback()
        flash(f'Error adding item to order: {str(e)}', 'error')
    
    return redirect(url_for('orders'))

@app.route('/orders/<int:order_id>/complete')
def complete_order(order_id):
    try:
        order = Order.query.get(order_id)
        if not order:
            flash('Order not found', 'error')
            return redirect(url_for('orders'))
            
        if order.status != 'completed':
            order.status = 'completed'
            
            customer = order.customer
            if customer:
                customer.visit_count = (customer.visit_count or 0) + 1
                
                current_total_spent = safe_decimal(customer.total_spent)
                order_total = safe_decimal(order.total_amount)
                customer.total_spent = current_total_spent + order_total
                customer.last_visit = datetime.utcnow()
            
            db.session.commit()
            flash('Order completed successfully!', 'success')
        else:
            flash('Order is already completed', 'info')
            
    except Exception as e:
        db.session.rollback()
        flash(f'Error completing order: {str(e)}', 'error')
    
    return redirect(url_for('orders'))

@app.route('/inventory')
def inventory():
    try:
        inventory_items = Inventory.query.all()
        suppliers = Supplier.query.all()
        return render_template('inventory.html', inventory=inventory_items, suppliers=suppliers)
    except Exception as e:
        flash(f"Error loading inventory: {str(e)}", "error")
        return render_template('inventory.html', inventory=[], suppliers=[])

@app.route('/inventory/add', methods=['POST'])
def add_inventory():
    try:
        item_name = get_form_value('item_name', required=True)
        quantity = safe_decimal(request.form.get('quantity'))
        unit = get_form_value('unit', required=True)
        supplier_id = request.form.get('supplier_id')
        reorder_level = safe_decimal(request.form.get('reorder_level', '0'))
        
        if quantity < 0:
            flash('Quantity cannot be negative', 'error')
            return redirect(url_for('inventory'))
        
        new_inventory = Inventory(
            item_name=item_name.strip(),
            quantity=quantity,
            unit=unit.strip(),
            supplier_id=int(supplier_id) if supplier_id else None,
            reorder_level=reorder_level
        )
        
        db.session.add(new_inventory)
        db.session.commit()
        flash('Inventory item added successfully!', 'success')
        
    except ValueError as e:
        db.session.rollback()
        flash(str(e), 'error')
    except Exception as e:
        db.session.rollback()
        flash(f'Error adding inventory item: {str(e)}', 'error')
    
    return redirect(url_for('inventory'))

@app.route('/analytics')
def analytics():
    try:
        menu_items = MenuItem.query.all()
        profit_data = []
        for item in menu_items:
            total_sold = sum(oi.quantity for oi in item.order_items)
            
            selling_price = safe_decimal(item.selling_price)
            cost_price = safe_decimal(item.cost_price)
            
            total_profit = total_sold * (selling_price - cost_price)
            profit_data.append({
                'name': item.name,
                'total_sold': total_sold,
                'total_profit': float(total_profit),
                'margin': float(selling_price - cost_price)
            })
        
        customers = Customer.query.all()
        customer_stats = []
        for customer in customers:
            order_count = customer.visit_count or 0
            total_spent = safe_decimal(customer.total_spent)
            
            avg_order_value = float(total_spent / order_count) if order_count > 0 else 0
            
            customer_stats.append({
                'name': customer.name,
                'order_count': order_count,
                'total_spent': float(total_spent),
                'avg_order_value': avg_order_value,
                'last_visit': customer.last_visit.strftime('%Y-%m-%d %H:%M') if customer.last_visit else 'Never'
            })
        
        return render_template('analytics.html', profit_data=profit_data, customer_stats=customer_stats)
    except Exception as e:
        flash(f"Error loading analytics: {str(e)}", "error")
        return render_template('analytics.html', profit_data=[], customer_stats=[])

@app.route('/customer_stats')
def customer_stats():
    try:
        customers_list = Customer.query.all()
        return render_template('customer_stats.html', customers=customers_list)
    except Exception as e:
        flash(f"Error loading customer statistics: {str(e)}", "error")
        return render_template('customer_stats.html', customers=[])

# Database maintenance routes (should be protected in production)
@app.route('/migrate_database')
def migrate_database():
    """Add missing columns to customers table"""
    if not app.debug:
        flash('This route is only available in debug mode', 'error')
        return redirect(url_for('index'))
        
    try:
        with app.app_context():
            # Check and add visit_count column
            try:
                db.session.execute(text("ALTER TABLE customers ADD COLUMN visit_count INT DEFAULT 0"))
                flash("Added visit_count column", "success")
            except Exception as e:
                flash(f"visit_count column: {e}", "info")
            
            # Check and add total_spent column
            try:
                db.session.execute(text("ALTER TABLE customers ADD COLUMN total_spent DECIMAL(12,2) DEFAULT 0.00"))
                flash("Added total_spent column", "success")
            except Exception as e:
                flash(f"total_spent column: {e}", "info")
            
            # Check and add last_visit column
            try:
                db.session.execute(text("ALTER TABLE customers ADD COLUMN last_visit DATETIME NULL"))
                flash("Added last_visit column", "success")
            except Exception as e:
                flash(f"last_visit column: {e}", "info")
            
            db.session.commit()
            
        return render_template('migration_success.html')
        
    except Exception as e:
        db.session.rollback()
        flash(f'Database migration failed: {str(e)}', 'error')
        return redirect(url_for('index'))

@app.route('/fix_customer_stats')
def fix_customer_stats():
    """Fix customer statistics by recalculating from completed orders"""
    if not app.debug:
        flash('This route is only available in debug mode', 'error')
        return redirect(url_for('index'))
        
    try:
        customers = Customer.query.all()
        updated_count = 0
        
        for customer in customers:
            completed_orders = Order.query.filter_by(customer_id=customer.customer_id, status='completed').all()
            
            visit_count = len(completed_orders)
            total_spent = Decimal('0.00')
            last_visit = None
            
            for order in completed_orders:
                order_total = safe_decimal(order.total_amount)
                total_spent += order_total
                
                if not last_visit or order.order_date > last_visit:
                    last_visit = order.order_date
            
            customer.visit_count = visit_count
            customer.total_spent = total_spent
            customer.last_visit = last_visit
            
            if visit_count > 0:
                updated_count += 1
        
        db.session.commit()
        flash(f'Updated {updated_count} customer statistics', 'success')
        
    except Exception as e:
        db.session.rollback()
        flash(f'Error fixing customer statistics: {str(e)}', 'error')
    
    return redirect(url_for('customer_stats'))

@app.route('/fix_totals')
def fix_totals():
    """Recalculate all order totals"""
    if not app.debug:
        flash('This route is only available in debug mode', 'error')
        return redirect(url_for('index'))
        
    try:
        orders = Order.query.all()
        updated_order_count = 0
        
        for order in orders:
            calculated_total = Decimal('0.00')
            for item in order.order_items:
                quantity = safe_decimal(item.quantity)
                unit_price = safe_decimal(item.unit_price)
                calculated_total += quantity * unit_price
            
            current_total = safe_decimal(order.total_amount)
            if current_total != calculated_total:
                order.total_amount = calculated_total
                updated_order_count += 1
        
        db.session.commit()
        flash(f'Updated {updated_order_count} order totals', 'success')
        
    except Exception as e:
        db.session.rollback()
        flash(f'Error fixing order totals: {str(e)}', 'error')
    
    return redirect(url_for('orders'))

# Debug routes (only available in debug mode)
@app.route('/debug_order/<int:order_id>')
def debug_order(order_id):
    if not app.debug:
        flash('Debug routes are only available in debug mode', 'error')
        return redirect(url_for('index'))
        
    try:
        order = Order.query.get(order_id)
        if not order:
            flash('Order not found', 'error')
            return redirect(url_for('orders'))
        
        calculated_total = Decimal('0.00')
        for item in order.order_items:
            quantity = safe_decimal(item.quantity)
            unit_price = safe_decimal(item.unit_price)
            calculated_total += quantity * unit_price
        
        current_total = safe_decimal(order.total_amount)
        difference = calculated_total - current_total
        
        return render_template('debug_order.html', order=order, calculated_total=calculated_total, difference=difference)
        
    except Exception as e:
        flash(f'Error debugging order: {str(e)}', 'error')
        return redirect(url_for('orders'))

@app.route('/debug_customer/<int:customer_id>')
def debug_customer(customer_id):
    if not app.debug:
        flash('Debug routes are only available in debug mode', 'error')
        return redirect(url_for('index'))
        
    try:
        customer = Customer.query.get(customer_id)
        if not customer:
            flash('Customer not found', 'error')
            return redirect(url_for('customers'))
        
        completed_orders = Order.query.filter_by(customer_id=customer_id, status='completed').all()
        return render_template('debug_customer.html', customer=customer, completed_orders=completed_orders)
        
    except Exception as e:
        flash(f'Error debugging customer: {str(e)}', 'error')
        return redirect(url_for('customers'))

# API routes
@app.route('/api/orders')
def api_orders():
    try:
        orders = Order.query.all()
        orders_data = []
        for order in orders:
            total_amount = safe_decimal(order.total_amount)
            
            orders_data.append({
                'order_id': order.order_id,
                'customer_name': order.customer.name if order.customer else 'Walk-in',
                'total_amount': float(total_amount),
                'status': order.status,
                'order_date': order.order_date.strftime('%Y-%m-%d %H:%M')
            })
        return jsonify(orders_data)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)