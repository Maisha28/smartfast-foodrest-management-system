from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from decimal import Decimal

db = SQLAlchemy()

class Customer(db.Model):
    __tablename__ = 'customers'
    customer_id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False)
    email = db.Column(db.String(150), unique=True)
    phone = db.Column(db.String(30))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # ADD THESE THREE COLUMNS:
    visit_count = db.Column(db.Integer, default=0)
    total_spent = db.Column(db.Numeric(12, 2), default=0.00)
    last_visit = db.Column(db.DateTime, nullable=True)
    
    orders = db.relationship('Order', backref='customer', lazy=True)
    feedbacks = db.relationship('Feedback', backref='customer', lazy=True)

class Supplier(db.Model):
    __tablename__ = 'suppliers'
    supplier_id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False)
    contact = db.Column(db.String(150))
    address = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    inventory_items = db.relationship('Inventory', backref='supplier', lazy=True)

class Staff(db.Model):
    __tablename__ = 'staff'
    staff_id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False)
    role = db.Column(db.String(80))
    phone = db.Column(db.String(30))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    orders_created = db.relationship('Order', backref='staff', lazy=True)

class Inventory(db.Model):
    __tablename__ = 'inventory'
    inventory_id = db.Column(db.Integer, primary_key=True)
    item_name = db.Column(db.String(150), nullable=False)
    quantity = db.Column(db.Numeric(12, 3), nullable=False, default=0)
    unit = db.Column(db.String(20), default='unit')
    expiry_date = db.Column(db.Date)
    supplier_id = db.Column(db.Integer, db.ForeignKey('suppliers.supplier_id'))
    reorder_level = db.Column(db.Numeric(12, 3), default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    recipe_ingredients = db.relationship('RecipeIngredient', backref='inventory', lazy=True)
    waste_logs = db.relationship('WasteLog', backref='inventory', lazy=True)
    audit_logs = db.relationship('InventoryAudit', backref='inventory', lazy=True)

class MenuItem(db.Model):
    __tablename__ = 'menu_items'
    item_id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False)
    cost_price = db.Column(db.Numeric(10, 2), nullable=False)
    selling_price = db.Column(db.Numeric(10, 2), nullable=False)
    active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    order_items = db.relationship('OrderItem', backref='menu_item', lazy=True)
    recipe_ingredients = db.relationship('RecipeIngredient', backref='menu_item', lazy=True)

class Order(db.Model):
    __tablename__ = 'orders'
    order_id = db.Column(db.Integer, primary_key=True)
    customer_id = db.Column(db.Integer, db.ForeignKey('customers.customer_id'))
    order_date = db.Column(db.DateTime, default=datetime.utcnow)
    total_amount = db.Column(db.Numeric(12, 2), default=0)
    status = db.Column(db.Enum('pending', 'completed', 'cancelled'), default='pending')
    created_by_staff = db.Column(db.Integer, db.ForeignKey('staff.staff_id'))
    
    order_items = db.relationship('OrderItem', backref='order', lazy=True, cascade='all, delete-orphan')
    feedback = db.relationship('Feedback', backref='order', lazy=True, uselist=False)

class OrderItem(db.Model):
    __tablename__ = 'order_items'
    order_item_id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey('orders.order_id'))
    item_id = db.Column(db.Integer, db.ForeignKey('menu_items.item_id'))
    quantity = db.Column(db.Integer, nullable=False)
    unit_price = db.Column(db.Numeric(10, 2), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Feedback(db.Model):
    __tablename__ = 'feedback'
    feedback_id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey('orders.order_id'))
    customer_id = db.Column(db.Integer, db.ForeignKey('customers.customer_id'))
    rating = db.Column(db.Integer)
    comment = db.Column(db.Text)
    feedback_date = db.Column(db.DateTime, default=datetime.utcnow)

class WasteLog(db.Model):
    __tablename__ = 'waste_log'
    waste_id = db.Column(db.Integer, primary_key=True)
    inventory_id = db.Column(db.Integer, db.ForeignKey('inventory.inventory_id'))
    date = db.Column(db.Date, default=datetime.utcnow().date)
    quantity = db.Column(db.Numeric(12, 3), nullable=False)
    reason = db.Column(db.String(255))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class RecipeIngredient(db.Model):
    __tablename__ = 'recipe_ingredients'
    recipe_id = db.Column(db.Integer, primary_key=True)
    item_id = db.Column(db.Integer, db.ForeignKey('menu_items.item_id'))
    inventory_id = db.Column(db.Integer, db.ForeignKey('inventory.inventory_id'))
    qty_required = db.Column(db.Numeric(12, 4), nullable=False)

class InventoryAudit(db.Model):
    __tablename__ = 'inventory_audit'
    audit_id = db.Column(db.Integer, primary_key=True)
    inventory_id = db.Column(db.Integer, db.ForeignKey('inventory.inventory_id'))
    change_qty = db.Column(db.Numeric(12, 3))
    reason = db.Column(db.String(255))
    audit_time = db.Column(db.DateTime, default=datetime.utcnow)