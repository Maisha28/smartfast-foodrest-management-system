-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: smartfast_pdf
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customers` (
  `customer_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `email` varchar(150) DEFAULT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `visit_count` int DEFAULT '0',
  `total_spent` decimal(12,2) DEFAULT '0.00',
  `last_visit` date DEFAULT NULL,
  PRIMARY KEY (`customer_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (1,'Riya','riya12@gmail.com','9876543210','2025-11-06 07:08:58',2,790.00,'2025-11-23'),(2,'Aman','aman@example.com','9123456789','2025-11-06 07:08:58',3,530.00,'2025-11-10'),(3,'Sneha','sneha@example.com','9012345678','2025-11-06 07:08:58',2,1460.00,'2025-11-11'),(4,'rohan','rohan@gmail.com','9865411232','2025-11-07 23:36:23',0,0.00,NULL),(5,'mishka','mishka123@gmail.com','9987652121','2025-11-08 00:32:11',1,300.00,'2025-11-08'),(6,'maisha','vageriyamaisha@gmail.com','8830316742','2025-11-08 02:55:26',3,1990.00,'2025-11-23'),(7,'kaashvi','kaashvi8@hotmail.com','9819372432','2025-11-08 02:56:36',0,0.00,NULL),(8,'shrey','shrey.vadhani@gmail.com','9913234532','2025-11-10 03:39:39',0,0.00,NULL),(9,'arya','arya@gmail.com','9876555555','2025-11-11 01:05:23',0,0.00,NULL),(10,'sanvi','sanvi@gmail.com','987766554433','2025-11-11 01:16:31',0,0.00,NULL),(11,'muskan','muskan@gmail.com','9082160947','2025-11-11 01:25:53',2,140.00,'2025-11-23'),(12,'fiona','fiona@gmail.com','907876555','2025-11-11 01:29:53',0,0.00,NULL),(13,'mayuri','mayuritarde5@gmail.com','8942567819','2025-11-12 00:12:29',1,400.00,'2025-11-12'),(14,'puneet','puneet@gmail.com','9988776655','2025-11-12 01:42:32',1,900.00,'2025-11-12');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-23 17:50:59
